import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sjpr/screen/invoice/custom_camera.dart';

class ImageStack extends StatelessWidget {
  late List<CaptureModel> widgets = [];

  ImageStack({super.key, required this.widgets});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Stack(
        children: getChildren(),
      ),
    );
  }

  getChildren() {
    List<Widget> positioned = [];
    for (int i = 1; i <= widgets.length; i++) {
      positioned.add(Positioned(
        left: 2.0 * i,
        top: 2.0 * i,
        child: SizedBox(
          width: 80,
          height: 80,
          child: widgets[i - 1].widget,
        ),
      ));
    }
    return positioned;
  }
}
