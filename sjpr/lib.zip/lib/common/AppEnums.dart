enum SheetType {
  category,
  product,
  itemclass,
  location,
  customer,
  taxrate,
  type,
  currency,
  paymentmethods,
  publishto,
  none
}
