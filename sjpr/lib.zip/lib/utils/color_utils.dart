import 'package:flutter/material.dart';

Color backGroundColor = Colors.black;
Color textColor = Colors.white;
Color activeTxtColor = const Color.fromRGBO(182, 147, 52, 1);
Color buttonTextColor = Colors.black;
Color buttonBgColor = const Color.fromRGBO(182, 147, 52, 1);
Color listTileBgColor = const Color(0xFF2C2D33);
Color redColor = const Color(0xFFD22B2B);

Color textFieldBgColor = const Color(0xFF272829);
Color profileBgColor = const Color(0xFFB49334);
Color profileListBgColor = const Color(0xFFD4B350);
